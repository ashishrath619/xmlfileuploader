import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import RouterConfig from "./Components/Navigation/RouterConfig";

function App() {
  return (
    <div>
      <RouterConfig />
    </div>
  );
}

export default App;
